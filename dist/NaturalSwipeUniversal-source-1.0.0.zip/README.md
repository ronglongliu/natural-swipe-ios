# Natural Swipe Universal 1.0.0

这是给 **TrollFools 手动注入 App** 使用的通用版 dylib。它不是当前已安装的拼多多专用插件，也不包含 TweakInject plist、SpringBoard Filter 或安装脚本。

## 文件

- `NaturalSwipeUniversal.dylib`：直接选择注入的主文件。
- `src/`：独立通用源码。
- `build.py`：在本机真实 iOS 16.5 SDK 上重新构建。
- `THIRD_PARTY.md`、`licenses/`：KIF/PTFakeTouch参考和许可。

## 功能

- 注入进普通 App 进程后自动初始化，不再检查 `com.xunmeng.pinduoduo`。
- 轻点浮窗按当前 App 独立配置立即开始；运行中轻点停止。
- 长按约0.55秒打开速度、间隔、次数、方向和个人节奏菜单。
- 拖动后自动贴左/右边并记忆位置；5秒无真实触摸缩成侧边小拉手，运行继续。
- 次数 `0` 表示无限；默认方向为手指向上。
- 每个 App 的配置、样本和事件日志写到该 App 自己的 `Documents/NaturalSwipe/`，不会复用拼多多的样本。
- 仅在主 `.app` 中初始化，跳过扩展、SpringBoard和backboardd；有进程内重复初始化保护，检测到旧拼多多版已加载时通用版不启用。

## TrollFools 使用

1. 只选目标 App 的主 App，不选 SpringBoard，也不选系统扩展。
2. 用 TrollFools 注入 `NaturalSwipeUniversal.dylib`。
3. 重新启动被注入的 App。App 更新或重装后通常需要重新注入。
4. 首次进入前台后等待约2秒，右侧出现“滑动”浮窗。
5. 轻点开始，长按设置；首次使用每个 App 都需要单独设置速度/间隔/次数。

当前构建通过 `MSHookMessageEx` 优先挂接 `UIApplication sendEvent:`；若运行环境未提供 ElleKit，代码才尝试 Objective-C runtime 备用挂接。备用方式是兼容性兜底，不等同于已对所有 App 验证。

## 已知边界

这次按用户要求**只编译打包，未对通用版做真机测试或安装**。产物是`arm64` slice，最低目标iOS 15.0；不要注入仅接受arm64e的系统进程。原始实现只在 iOS 16.5、拼多多和独立 UIKit 验收 App 中验证过，不能承诺所有 App 直接兼容。

最适合原生 `UIScrollView`、`UITableView`、`UICollectionView` 信息流。复杂 SwiftUI、自定义手势、WKWebView、Unity/Metal 自绘页面可能无法识别可滚动祖先或需要单独适配。横屏页面会停止；文本输入、键盘和非滚动页面会停止；后台/失去活跃状态会停止。

不要在同一个 App 同时注入当前拼多多版 `NaturalSwipe.dylib` 和本通用版。不要注入 SpringBoard。TrollFools 注入的 App 更新后需重新注入，旧容器中的 `Documents/NaturalSwipe/` 数据是否保留取决于 App 更新方式。

## 构建

```sh
python3 build.py
```

构建产物为 arm64 iOS dylib，最低目标 iOS 15.0，使用 `/tmp/sdks/iPhoneOS16.5.sdk` 和本机 iostoolchain 的 Linux `ldid` 签名。该文件是供 TrollFools 使用的 App 注入产物，不是 Sileo deb。
