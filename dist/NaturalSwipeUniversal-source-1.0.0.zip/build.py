#!/usr/bin/env python3
from pathlib import Path
import hashlib, os, shutil, subprocess

R = Path(__file__).parent
S = Path('/tmp/sdks/iPhoneOS16.5.sdk')
OUT = R / 'NaturalSwipeUniversal.dylib'
BASE = [
    'clang', '-target', 'arm64-apple-ios15.0', '-isysroot', str(S),
    '-fobjc-arc', '-fblocks', '-O2', '-fuse-ld=lld',
    '-framework', 'UIKit', '-framework', 'Foundation',
    '-framework', 'QuartzCore', '-framework', 'CoreFoundation',
    '-framework', 'CoreGraphics',
]

def run(args):
    subprocess.run([str(x) for x in args], check=True)

def sign(path):
    tool = Path('/tmp/natural-swipe-universal-ldid')
    shutil.copy2('/var/minis/shared/iostoolchain/bin/ldid', tool)
    os.chmod(tool, 0o755)
    run([tool, '-S', path])

def main():
    if not S.exists():
        raise SystemExit(f'missing SDK: {S}')
    run(BASE + [
        '-shared', '-Wl,-install_name,@rpath/NaturalSwipeUniversal.dylib',
        R / 'src/NSSwipeEngine.m', R / 'src/NSController.m', '-o', OUT,
    ])
    sign(OUT)
    print('built:', OUT)
    print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())

if __name__ == '__main__':
    main()
